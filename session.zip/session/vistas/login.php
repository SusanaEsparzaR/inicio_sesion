<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro</title>
    <link rel="shortcut icon" href="#">
    <link rel="stylesheet" href="../main.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<script type="text/javascript" language="javascript">
        var password, password2;

        password = document.getElementById('contraseña');
        password2 = document.getElementById('contraseña2');

        //password.onchange = password2.onkeyup = passwordMatch;

        function passwordMatch() {
            if(password.value !== password2.value)
                password2.setCustomValidity('Las contraseñas no coinciden.');
            else
                password2.setCustomValidity('');
                if(strlen($password) < 8){
                    $error_clave = "La clave debe tener al menos 8 caracteres";
                    return false;
                }
                if (!preg_match('`[a-z]`',$password)){
                    $error_clave = "La clave debe tener al menos una letra minúscula";
                    return false;
                }
                if (!preg_match('`[A-Z]`',$password)){
                    $error_clave = "La clave debe tener al menos una letra mayúscula";
                    return false;
                }
                if (!preg_match('`[0-9]`',$password)){
                    $error_clave = "La clave debe tener al menos un caracter numérico";
                    return false;
                }
        }

        function validaNumericos(event) {
    if(event.charCode >= 48 && event.charCode <= 57){
      return true;
     }
     return false;        
    }

        function send() {
            var nombre = document.getElementById('nombre').value;
            var apellido = document.getElementById('apellido').value;
            var apellido2 = document.getElementById('apellido2').value;
            var telefono = document.getElementById('telefono').value;
            var ciudad = document.getElementById('ciudad').value;
            var estado = document.getElementById('estado').value;
            var correo = document.getElementById('correo').value;
            var contrasenia = document.getElementById('contrasenia').value;
            var contrasenia2 = document.getElementById('contrasenia2').value;
            var requestBody = {
                "first_name": nombre,
                "middle_name": apellido,
                "last_name": apellido2,
                "phone_number": telefono,
                "address":{
                    "city": ciudad,
                    "state": estado
                },
                "email": correo,
                "password": contrasenia,
                "password_confirmation": contrasenia
                }
            URL = "http://35.167.62.109/storeutags/security/create_account";
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.open("POST", URL, false);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.send(JSON.stringify(requestBody));
            console.log(xmlhttp);
        }

        function callbackFunction(xmlhttp){
            alert("Respuesta recibida");
            console.log(xmlhttp.responseXML);
        }

    </script>
    <body>
        <form action="vistas/inicio.php" method="POST">
            <?php
                if(isset($errorLogin)){
                    echo $errorLogin;
                }
            ?>
            <h2>Registrar usuario</h2>
            <p>Nombre: <br>
            <input id="nombre" type="text" name="frist_name" placeholder="Ingresa tu nombre" required ></p>
            <p>Primer Apellido: <br>
            <input id="apellido" type="text" name="middle_name" placeholder="Ingresa tu primer apellido" required></p>
            <p>Segundo Apellido: <br>
            <input id="apellido2" type="text" name="last_name" placeholder="Ingresa tu segundo apellido" required></p>
            <p>Número de télefono: <br>
            <input id="telefono" type="text" name="phone_number" placeholder="Ingresa tu telefono" minlength="10" required onkeypress='return event.charCode >= 48 && event.charCode <= 57'></p>
            <p>Ciudad: <br>
            <input id="ciudad" type="text" name="city" placeholder="Ingresa tu ciudad" required></p>
            <p>Estado: <br>
            <input id="estado" type="text" name="state" placeholder="Ingresa tu estado" required></p>
            <p>Correo: <br>
            <input id="correo" type="email" name="email" placeholder="Ingresa tu correo" required></p>
            <p>Contraseña: <br>
            <input id="contrasenia" type="password" name="password" placeholder="Ingresa tu contraseña"  minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></p>
            <p>Confirmar Contraseña: <br>
            <input type="password" id="contrasenia2" placeholder="Confirma tu contraseña" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></p>
            <div class="g-recaptcha" data-sitekey="6LcasUAaAAAAAMOWeFvqNPveo5w10NAnFhh56KP3"></div>
            <br/>
            <p class="center">
            <input type="submit" value="Registrar"  onBlur="send();"></p>
            <p class="center"><a href="vistas/inicio.php">Ya tengo una cuenta</a></p>
        </form>
    </body>
</html>