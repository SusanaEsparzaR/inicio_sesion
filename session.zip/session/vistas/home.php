<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="#">
        <link rel="stylesheet" href="../main.css">
        <title>Home</title>  
    </head>
    <body>
        <p style="text-align: right">
            <td><input type="text" id="nombre" value="" class="input" readonly></td>
            <a href="inicio.php" onClick="salir()"> Salir</a>
        </p>
    </body>
    <script>
        if(localStorage.getItem("email") && localStorage.getItem("password")){
            obtener_localstorage();
            myFunction();
        }else{
            console.log("Falta algún dato en el local storage");
            location.href ="http://session.test/vistas/inicio.php";
        }

        function obtener_localstorage(){
            let nombre = localStorage.getItem("full_name");
        }

        function myFunction() {
            var x = localStorage.getItem("full_name");
            document.getElementById("nombre").value = x;
        }

        function salir(){
            localStorage.removeItem('email');
            localStorage.removeItem('password');
            localStorage.removeItem('caja');
            localStorage.removeItem('full_name');
            localStorage.removeItem('respuesta');
        }
        </script>
</html>