<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Inicio de sesión</title>
        <link rel="shortcut icon" href="#">
        <link rel="stylesheet" href="../main.css">
    </head>
    <body>
        
        <form action="home.php" method="POST">
            <p class="center"><h2>Inicio de sesión</h2></p>
            <p>Correo: <br>
            <input type="text" name="correo" id="correo" placeholder="Ingresa tu correo"  required></p>
            <p>Contraseña: <br>
            <input type="password" name="password" id="contra" placeholder="Ingresa tu contraseña" required></p>
            <input type="checkbox" name="remember" id="checkbox">
            <label for="checkbox">Recordar datos de usuario</label>
            <br/>
            <p class="center"><input type="submit" value="Entrar" onClick="guardar_localstorage();"></p>

            <p class="center"><a href="form_cambio_contra.php">¿Olvidaste tu contraseña?</a></p>
            <p class="center">¿Todavía no tienes una cuenta?<a href="login.php"> Registrate</a></p>
        </form>
    </body>
    <script>
            if(localStorage.getItem("email") && localStorage.getItem("password") && localStorage.getItem("caja")){
                obtener_localstorage();
                inicio();
            }else{
                console.log("Aún no guarda usuario")
            }

            function obtener_localstorage(){
                var x = localStorage.getItem("email");
                document.getElementById("correo").value = x;
                var xy = localStorage.getItem("password");
                document.getElementById("contra").value = xy;
            }


            function guardar_localstorage(){
                let caja = document.getElementById('checkbox').value;
                let email = document.getElementById('correo').value;
                let password = document.getElementById('contra').value;

                localStorage.setItem("caja", caja);
                localStorage.setItem("email", email);
                localStorage.setItem("password", password);
                localStorage.setItem("full_name", full_name);

                var requestBody = {
                "email": email,
                "password": password
                }
                URL = "http://35.167.62.109/storeutags/security/login ";
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
                xmlhttp.open("POST", URL, false);
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
                xmlhttp.send(JSON.stringify(requestBody));
            }

        function callbackFunction(xmlhttp){
            alert("Respuesta recibida");
            console.log(xmlhttp.responseXML);
        }

        function inicio(){
            location.href ="http://session.test/vistas/home.php";
        }
        </script>
</html>